/*
    Global State

    Stores loaded player data, current draft year,
    available leagues, and comparison data.
*/

let allPlayers = [];

let currentYear = "2027";

let allowedLeagues = [];

let allComps = {};

let currentSort = "";
let sortAscending = true;
/*
    Player Type Helpers

    Determines player categories used throughout
    the application.
*/

function isGoalie(player) {
    return (player.position ?? []).includes("G");
}


/*
    Application Startup

    Loads required data before displaying rankings.
*/

loadLeagues().then(() => {

    loadPlayers(currentYear);
    loadComps(currentYear);

});


/*
    Comparison Data Loading

    Loads comparison JSON for the selected
    draft year.
*/

function loadComps(year) {

    return fetch(`../data/comps_${year}.json`)
        .then(response => {

            if (!response.ok) {

                throw new Error(
                    `comps_${year}.json returned HTTP ${response.status}`
                );
            }

            return response.json();

        })

        .then(data => {

            allComps = data;
        })

        .catch(error => {
            console.error(
                "Comps loading failed:",
                error.message
            );

            allComps = {};
        });
}


/*
    Team Filtering
    Returns only teams belonging to leagues
    included in the ranking system.
*/

function getDisplayTeams(player) {

    const teams =
        player.performanceStats?.teams ?? [];


    return teams
        .filter(
            t => allowedLeagues.includes(t.league)
        )
        .sort(
            (a, b) => {

                // newest season first
                const seasonCompare =
                    b.season.localeCompare(a.season);


                if (seasonCompare !== 0) {
                    return seasonCompare;
                }


                // same season:
                // prioritize strongest league
                const leagueA =
                    player.leagueBreakdown?.find(
                        x =>
                        x.team === a.team &&
                        x.league === a.league
                    )?.weight ?? 0;


                const leagueB =
                    player.leagueBreakdown?.find(
                        x =>
                        x.team === b.team &&
                        x.league === b.league
                    )?.weight ?? 0;


                return leagueB - leagueA;

            }
        );

}


/*
    League Loading
    Loads available leagues from the ranking
    configuration file.
*/

function loadLeagues() {

    return fetch("../data/league_weights.json")

        .then(response => response.json())

        .then(data => {

            allowedLeagues = Object.keys(data);

        })

        .catch(error => {

            console.error(
                "League loading failed:",
                error
            );
        });
}


/*
    Age Calculation

    Calculates current player age from
    date of birth.
*/

function calculateAge(dateOfBirth) {

    if (!dateOfBirth)

        return "";

    const birthDate = new Date(dateOfBirth);

    const today = new Date();


    const milliseconds =
        today - birthDate;

    const years =
        milliseconds /
        (1000 * 60 * 60 * 24 * 365.25);

    return years.toFixed(1);

}


/*
    Nationality Flags
    Converts country names into flag icons.
*/

function getFlag(country) {

    const flags = {

        "Canada": "ca",
        "USA": "us",
        "United States": "us",
        "Russia": "ru",
        "Sweden": "se",
        "Finland": "fi",
        "Czech Republic": "cz",
        "Czechia": "cz",
        "Slovakia": "sk",
        "Germany": "de",
        "Switzerland": "ch",
        "Latvia": "lv",
        "Denmark": "dk",
        "Norway": "no",
        "France": "fr",
        "Austria": "at",
        "Belarus": "by",
        "Kazakhstan": "kz",
        "Ukraine": "ua"

    };

    const code = flags[country];

    if (!code) {

        return "";

    }

    return `<span class="fi fi-${code}"></span>`;

}

/*
    Player Loading

    Loads ranked player JSON and populates
    the main prospect table.
*/

function loadPlayers(year) {

    fetch(`../data/ranked_${year}.json`)

        .then(response => response.json())

        .then(players => {

            allPlayers = players;

            addPlayerBadges();

            redrawTable();

        })

        .catch(error => {

            console.error(
                "Player loading failed:",
                error
            );

        });

}
/*
    Draft Year Selection

    Reloads player rankings when the selected
    draft year changes.
*/

document
    .getElementById("draft-year")
    .addEventListener(
        "change",
        function () {

            currentYear = this.value;

            loadPlayers(currentYear);

        }
    );


/*
    Badge Generation

    Adds visual badges to notable prospects.
*/

function addPlayerBadges() {

    allPlayers.forEach(player => {

        player.badges = [];


        if (player.customRank <= 10) {

            player.badges.push(
                "&#128293; Top 10 Prospect"
            );

        }

    });

}


/*
    Player Profile Click Handler

    Detects player links and opens
    the selected player's profile.
*/

document.addEventListener(
    "click",
    function (event) {


        if (
            event.target.classList.contains(
                "player-link"
            )
        ) {


            event.preventDefault();


            const name =
                event.target.dataset.name;


            const player =
                allPlayers.find(
                    p => p.name === name
                );


            showPlayer(player);

        }

    }
);


/*
    League Score History

    Creates season history data for
    the player profile card.

    Filters duplicate teams and matches
    weighted scoring information from
    the ranker output.
*/

function getLeagueScores(player) {

    return player.leagueBreakdown ?? [];

}


/*
    Player Profile Display

    Builds the player scouting card,
    projection information, season history,
    and draft score breakdown.
*/

function showPlayer(player) {



    if (!player)

        return;



    const breakdown =
        player.scoreBreakdown ?? {};



    const isDefenseman =
        (player.position ?? []).includes("D");



    const leagueScores =
        getLeagueScores(player);



    document.getElementById(
        "profile-content"
    ).innerHTML = `


<div class="profile-header">


    <!-- LEFT SIDE: BIO -->

    <div class="profile-bio">


        <h2>

        <a href="${player.url}" target="_blank">

        ${player.name}

        </a>

        </h2>



        <h3>
        Rank #${player.customRank}
        </h3>



        <div class="badges">

        ${
        (player.badges ?? [])
        .map(
            b => `<span class="badge">${b}</span>`
        )
        .join("")
        }

        </div>



        <p>

        ${getFlag(player.nationality)}

        ${player.nationality ?? ""}

        |

        ${(player.position ?? []).join(", ")}

        </p>



        <p>

        Born:
        ${player.dateOfBirth ?? ""}

        |

        Age:
        ${calculateAge(player.dateOfBirth)}

        </p>



        <p>

        Height:
        ${player.height ?? "N/A"}

        |

        Weight:
        ${player.weight ?? "N/A"} lbs

        </p>



        <p>

        <b>
        Size Profile:
        </b>

        ${player.scoreBreakdown?.sizeProfile ?? "Average"}

        </p>


    </div>



    <!-- RIGHT SIDE: SCOUTING -->

    <div class="profile-scouting">


        <h3 class="section-title">

        Scouting Report

        </h3>



        <div class="stars">

        ${"★".repeat(
            Math.round(player.projection?.stars ?? 0)
        )}

        ${"☆".repeat(
            5 - Math.round(player.projection?.stars ?? 0)
        )}

        </div>



        <p>

        <b>
        Player Type:
        </b>

        ${player.playerType ?? "Unknown"}

        </p>



        <p>

        <b>
        Projected Role:
        </b>

        ${player.projection?.role ?? ""}

        </p>



        ${
        player.projection?.summary
        ?
        `<p>
        ${player.projection.summary}
        </p>`
        :
        ""
        }


    </div>


</div>



<hr>



<h3 class="section-title">

Season History

</h3>



<div class="season-history">


${

leagueScores.map(t => `


<p>


<b>

${t.season}

</b>


<br>


${t.team}

(${t.league})


<br>


GP:

${t.gp}



${

isGoalie(player)

?

`

|

GAA:
${t.goalsAgainstAverage ?? "NA"}

|

SV%:
${t.savePercentage ?? "NA"}

|

SO:
${t.shutouts ?? 0}

|

W:
${t.wins ?? 0}

|

L:
${t.losses ?? 0}

`

:

`

|

G:
${t.goals ?? 0}

|

A:
${t.assists ?? 0}

|

PTS:
${t.points ?? 0}

`

}



|

PIM:

${t.pim ?? 0}



${

t.plusMinus != null

?

`| +/-: ${t.plusMinus}`

:

""

}



<br>



<b>


Draft Score Contribution:

${Number(
    isGoalie(player)
        ? (t.goalieContribution ?? 0)
        : (t.weightedPoints ?? 0)
).toFixed(2)}


</b>



</p>



<hr>


`).join("")

}


</div>



<div class="score-header-card">


<div class="score-label">

Total Draft Score

</div>



<div class="score-number">

${Number(player.draftScore ?? 0).toFixed(2)}

</div>


</div>



<hr class="section-divider">



<div class="score-card">


<h4>

Draft Score Breakdown

</h4>


${

isGoalie(player)

?

`


<div class="score-row">

<span>

GAA Performance

</span>

<span>

${Number(breakdown.goalieGAA ?? 0).toFixed(2)}

</span>

</div>



<div class="score-row">

<span>

Shutouts

</span>

<span>

${
(player.leagueBreakdown ?? [])
.reduce(
    (total, season) =>
        total + Number(season.shutouts ?? 0),
    0
)

}

</span>

</div>



<div class="score-row">

<span>

Games Played

</span>

<span>

${breakdown.gamesPlayed ?? 0}

</span>

</div>



<div class="score-row">

<span>

League Strength

</span>

<span>

${
(player.leagueBreakdown ?? [])

.map(

l => {

let label = l.league;


if (
    [
        "WHC-17",
        "WHC-18",
        "WHC-20",
        "WJC",
        "International-Jr"
    ].includes(l.league)
) {

    label += " (Tournament)";

}


return `${label}: x${Number(l.weight ?? 1).toFixed(2)}`;

}

)

.join("<br>")

}

</span>

</div>


`

:

`


<div class="score-row">

<span>

Production

</span>

<span>

${Number(breakdown.production ?? 0).toFixed(1)}

</span>

</div>



<div class="score-row">

<span>

League Strength

</span>

<span>

${
(player.leagueBreakdown ?? [])

.map(

l =>
`${l.league}: x${Number(l.weight ?? 1).toFixed(2)}`

)

.join("<br>")

}

</span>

</div>




<div class="score-row">

<span>

Position

</span>

<span>

x${Number(breakdown.position ?? 1).toFixed(2)}

</span>

</div>



<div class="score-row">

<span>

Position Production

</span>

<span>

x${Number(breakdown.positionProduction ?? 1).toFixed(2)}

</span>

</div>



<div class="score-row">

<span>

Elite Forward

</span>

<span>

x${Number(breakdown.eliteForward ?? 1).toFixed(2)}

</span>

</div>



<div class="score-row">

<span>

Elite Defense

</span>

<span>

x${Number(breakdown.eliteDefense ?? 1).toFixed(2)}

</span>

</div>



<div class="score-row">

<span>

Defense Rarity

</span>

<span>

${
isDefenseman
    ? `x${Number(breakdown.defenseRarity ?? 1).toFixed(2)}`
    : "N/A"
}

</span>

</div>



<div class="score-row">

<span>

RHD Bonus

</span>

<span>

${
isDefenseman
    ? `x${Number(breakdown.rhd ?? 1).toFixed(2)}`
    : "N/A"
}

</span>

</div>



<div class="score-row">

<span>

Games Played

</span>

<span>

x${Number(breakdown.sampleSize ?? 1).toFixed(2)}

</span>

</div>



<div class="score-row">

<span>

Size Profile

</span>

<span>

x${Number(breakdown.size ?? 1).toFixed(2)}

</span>

</div>



<div class="score-row">

<span>

Discipline

</span>

<span>

x${Number(breakdown.discipline ?? 1).toFixed(2)}

</span>

</div>



<div class="score-row">

<span>

Plus/Minus

</span>

<span>

x${Number(breakdown.plusMinus ?? 1).toFixed(2)}

</span>

</div>


`

}


</div>


`;

const profileEl =
    document.getElementById("profile");

profileEl.style.display = "block";

}

function redrawTable() {

    const table = document.getElementById("players");

    table.innerHTML = "";

    allPlayers
        .slice(0, 100)
        .forEach(player => {

            const stats = player.primaryStats ?? {};

            table.innerHTML += `

<tr>

<td>${player.customRank ?? ""}</td>

<td>
<a href="#" class="player-link" data-name="${player.name}">
${player.name}
</a>
</td>

<td>${(player.position ?? []).join(", ")}</td>

<td>${player.shoots ?? ""}</td>

<td>${player.height ?? ""}</td>

<td>${player.weight ?? ""}</td>

<td>${player.dateOfBirth ?? ""}</td>

<td>${getFlag(player.nationality)}</td>

<td>${stats.league ?? ""}</td>

<td>${getDisplayTeams(player)[0]?.team ?? ""}</td>

<td>${Math.round(stats.gp ?? 0)}</td>

<td>${isGoalie(player) ? "" : Math.round(stats.goals ?? 0)}</td>

<td>${isGoalie(player) ? "" : Math.round(stats.assists ?? 0)}</td>

<td>${isGoalie(player) ? "" : Math.round(stats.points ?? 0)}</td>

<td>${isGoalie(player) ? "" : Math.round(stats.plusMinus ?? 0)}</td>

<td>${Math.round(stats.pim ?? 0)}</td>

<td>${isGoalie(player) ? "" : Number(player.ppg ?? 0).toFixed(2)}</td>

<td>${isGoalie(player) ? (stats.goalsAgainstAverage ?? "NA") : ""}</td>

<td>${isGoalie(player) ? (stats.wins ?? 0) : ""}</td>

<td>${isGoalie(player) ? (stats.losses ?? 0) : ""}</td>

<td>${isGoalie(player) ? (stats.shutouts ?? 0) : ""}</td>

<td>${Number(player.draftScore ?? 0).toFixed(2)}</td>

</tr>

`;

        });

}


/*
    Close Profile Button

    Hides the player profile overlay.
*/

document
    .getElementById("close-profile")
    .addEventListener(
        "click",
        function () {

            document.getElementById(
                "profile"
            ).style.display = "none";

        }
    );

window.addEventListener("click", function(event) {

    const modal = document.getElementById("profile");

    if (event.target === modal) {

        modal.style.display = "none";

    }

});